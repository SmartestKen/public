#!/bin/bash
rm -rf /usr/bin/proxy
echo "uninstall done"
