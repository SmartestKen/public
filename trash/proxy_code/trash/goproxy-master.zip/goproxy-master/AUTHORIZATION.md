# GoProxy special authorization

1. gproxy uses GPLv3 source code open agreement, without permission, based on the project development software, derivative software, related software, must strictly abide by GPLv3, otherwise once found,
Will be harshly punished.

2. If the company or individual uses the project code to develop related software, derivative software, and does not want to comply with the GPLv3 agreement, need to obtain the author's "GoProxy special authorization" written authorization.

3. If "GoPro special authorization"is not available on this page,the" GoPro special authorization"is invalid.

4. A valid authorization number and expiration date are listed below.

Authorization number | Authorization validity period
:--- | :---
